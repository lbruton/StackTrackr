---
name: smoke-test
description: Automated smoke test runner for StakTrakr — starts a local HTTP server, runs Playwright specs via self-hosted browserless Docker, collects results, then files Linear bug issues for new findings and creates a run-record issue.
allowed-tools: Bash, mcp__claude_ai_Linear__create_issue, mcp__claude_ai_Linear__update_issue
---

# Smoke Test — StakTrakr

Automated QA smoke test running Playwright specs via self-hosted **browserless** Docker against the local app. No Browserbase, no cloud credits. The browser runs inside Docker and connects to the app at `host.docker.internal:8765` (which resolves to the host machine from inside the container).

**Spec inventory:** `tests/*.spec.js`. Full 13-check coverage tracked in STAK-210.

## Arguments

`$ARGUMENTS` can be:
- *(blank)* — full spec suite (`npm test`)
- `dry-run` — run all checks, no Linear issues
- `smoke` — smoke-tagged specs only (`npm run test:smoke`)

---

## Phase 0: Setup

### Step 1: Start HTTP server (if needed)

Check if the app is already being served:
```bash
curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8765/index.html
```

If not `200`, start one from the project root:
```bash
npx http-server . -p 8765 --silent &
sleep 1
curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8765/index.html
```

If still not `200`, abort with:
> "HTTP server failed to start on port 8765."

Record `BASE_URL = http://host.docker.internal:8765`

### Step 2: Verify browserless is running

```bash
curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/
```

If not `200`:
> "browserless is not running. Start it with:
> `cd devops/browserless && docker compose up -d`
> Then wait ~5 seconds and retry."

Abort if browserless cannot be reached.

### Step 3: Record run metadata

Note:
- Today's date (YYYY-MM-DD) and start time
- `BASE_URL`
- Arguments used

---

## Phase 1: Run Playwright Tests

Run the appropriate test command based on arguments:

**Full suite (default):**
```bash
BROWSER_BACKEND=browserless TEST_URL=http://host.docker.internal:8765 npm test
```

**Smoke-tagged only:**
```bash
BROWSER_BACKEND=browserless TEST_URL=http://host.docker.internal:8765 npm run test:smoke
```

Capture the full stdout/stderr output. Playwright will report:
- Number of tests run / passed / failed / skipped
- Test names and durations
- Failure details with error messages and line references

Classify results:
- All passed → `✅ PASS`
- Any skipped, no failures → `✅ PASS WITH WARNINGS`
- Any failures → `❌ FAIL`

---

## Phase 2: Results Summary

Print a results table:

```
Results
=======
| Test Name                        | Status       | Notes |
|----------------------------------|--------------|-------|
| browserless connection + load    | ✅/⚠️/❌/⏭️ | ... |
| [additional specs as added]      | ✅/⚠️/❌/⏭️ | ... |

Overall: ✅ PASS / ✅ PASS WITH WARNINGS / ❌ FAIL
```

Note: Full 13-check coverage (page load, spot prices, summary cards, inventory, filter chips, search, add/edit/delete item, activity log, card views, theme toggle, detail modal) is tracked in STAK-210.

---

## Phase 3: Known Bugs Registry

Before filing any issues, check each failure against the known active bugs.

**Do NOT file a new Linear issue for a known active bug.** Reference it in the run record only.

### Currently Known Active Bugs

| Bug ID | Description | Notes |
|---|---|---|
| BUG-001 | Search returns 0 results intermittently | Intermittent — not always triggered |
| BUG-002 | Autocomplete ghost text persists after modal close | Not always triggered |

### Resolved Bugs (do not re-file)

| Bug ID | Description | Resolved In |
|---|---|---|
| BUG-006 | Delete executed immediately with no confirmation dialog | v3.31.5 — replaced with `showBulkConfirm` DOM modal |
| STAK-206 | Card view items-per-page constraint never applied | Fixed in dev — `pagination.js` row vs item unit mismatch corrected |

If a failure matches a known bug → mark "known — skipping Linear issue".
If a failure is **new** → file a Linear issue in Phase 4.

---

## Phase 4: File Linear Issues (new findings only)

**Skip entirely if `dry-run` mode.** Instead, print what WOULD be filed.

For each **new** failure:

Call `mcp__claude_ai_Linear__create_issue`:
- **team:** `f876864d-ff80-4231-ae6c-a8e5cb69aca4`
- **title:** `BUG: [Test Name] — [brief description]`
- **priority:** `2` (High) for ❌ fail · `3` (Normal) for ⚠️ warn
- **labels:** `["Bug", "268350a3-f7e5-467c-b793-4924a40b922a"]` (Bug + Sonnet)
- **description:**

```markdown
## Bug Report — Smoke Test Run [DATE]

**Test:** [Test Name]
**Status:** ❌ Fail / ⚠️ Warn
**Environment:** http://host.docker.internal:8765; seed inventory
**Backend:** browserless Docker (local)

## Observed Behavior

[Playwright error output — include error message and line reference]

## Expected Behavior

[What should have happened]

## Reproduction Steps

1. Start browserless: `cd devops/browserless && docker compose up -d`
2. Start HTTP server: `npx http-server . -p 8765 --silent &`
3. Run: `BROWSER_BACKEND=browserless TEST_URL=http://host.docker.internal:8765 npm test`

---
_Surfaced during smoke test run on [DATE] via /smoke-test skill (Playwright + browserless)._
```

---

## Phase 5: Create Run Record Issue

**Skip if `dry-run` mode.**

Call `mcp__claude_ai_Linear__create_issue`:

- **team:** `f876864d-ff80-4231-ae6c-a8e5cb69aca4`
- **title:** `QA: Smoke Test Run — [DATE formatted as "Feb 20, 2026"] [EMOJI] [RESULT]`
- **priority:** `4` (Low)
- **labels:** `["645a4bb1-0c34-477f-a8a6-14b75762178e", "268350a3-f7e5-467c-b793-4924a40b922a"]` (Improvement + Sonnet)
- **description:**

```markdown
## Smoke Test Run — [DATE]

**Overall Result:** [OVERALL_RESULT]
**Run Method:** /smoke-test skill via Claude Code (Playwright + browserless Docker)
**Environment:** http://host.docker.internal:8765; seed inventory ([N] items)
**Backend:** browserless self-hosted Docker (local)
**Arguments:** [ARGUMENTS or "full suite"]

---

## Results

| Test Name | Status | Notes |
|---|---|---|
[results table rows]

---

## New Issues Filed

[List new Linear issues, or "None — all findings matched known active bugs"]

## Known Issues Observed (not re-filed)

[List known bugs triggered this run]

## Known Issues Not Triggered

[List known bugs that did NOT appear this run]

---

_Logged by Claude via /smoke-test skill. Running Playwright specs against local browserless Docker._
_Full 13-check coverage pending STAK-210._
```

After creating the run record issue, call `mcp__claude_ai_Linear__update_issue` to set status to **Done**.

---

## Phase 6: Confirm

```
Smoke test complete!
====================
Environment: http://host.docker.internal:8765 (local)
Backend: browserless Docker

Run Record: STAK-XXX → Done
  [url]

New bugs filed:
  STAK-XXX — [title]  (or "None")

Known bugs observed (not re-filed):
  BUG-001 — search intermittent  (or "None")
```

---

## Dry Run Mode

If `dry-run`:
- Run all Playwright specs normally
- Print the results table
- Show what Linear issues WOULD be created (title, priority, description preview)
- Do NOT call any Linear MCP tools
- End with: `Dry run complete — no Linear issues created.`

---

## Maintaining the Known Bugs Registry

When a bug is resolved and shipped, move it from Known Active Bugs to the Resolved table above. This ensures future runs correctly flag regressions rather than silently skipping them.
