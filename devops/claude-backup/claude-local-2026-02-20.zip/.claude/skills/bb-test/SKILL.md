---
name: bb-test
description: Browserbase integration test suite for StakTrakr — runs 18 checks against staktrakr.pages.dev using Stagehand natural-language browser automation, collects results, files Linear issues for new findings, and creates a run-record issue.
allowed-tools: Bash, mcp__browserbase__browserbase_session_create, mcp__browserbase__browserbase_session_close, mcp__browserbase__browserbase_stagehand_navigate, mcp__browserbase__browserbase_stagehand_act, mcp__browserbase__browserbase_stagehand_extract, mcp__browserbase__browserbase_stagehand_observe, mcp__browserbase__browserbase_screenshot, mcp__claude_ai_Linear__create_issue, mcp__claude_ai_Linear__update_issue
---

# Browserbase Integration Test — StakTrakr

> ## REQUIRES EXPLICIT USER APPROVAL BEFORE RUNNING
>
> **Browserbase uses paid cloud credits.** This skill must NOT be invoked unless the user has explicitly requested it in this session (e.g., "run bb-test", "run the Browserbase test").
>
> **Default testing tool is browserless (local Docker) — free and self-hosted.**
> Use `/smoke-test` for scripted Playwright checks. Reserve bb-test for:
> - Natural-language flows that are hard to script precisely
> - Cross-environment verification (staktrakr.pages.dev vs local)
> - Explicit QA passes before a release
>
> If in doubt, ask before running.

Fully automated QA integration test covering 18 StakTrakr flows, driven by Browserbase Stagehand tools against the staktrakr.pages.dev (dev branch). No local server or Chrome extension required. All browser interactions use natural language via `stagehand_act` and `stagehand_extract` — **no `javascript_tool`**.

Session video is automatically recorded by Browserbase and available in the dashboard.

## Arguments

`$ARGUMENTS` can be:
- *(blank)* — full 18-check suite + Linear reporting
- `dry-run` — all checks, no Linear issues
- `quick` — core 13 checks only, skip extended checks (14-18)
- `checks 1,5,14` — run specific check numbers only
- `NUMISTA_KEY=xxx` — inject Numista API key for Check 14

Multiple arguments can be combined: `dry-run NUMISTA_KEY=xxx`, `quick dry-run`.

Parse `$ARGUMENTS`:
- `DRY_RUN` = true if "dry-run" present
- `QUICK` = true if "quick" present
- `CHECK_LIST` = parsed from "checks N,N,N" if present (otherwise all)
- `NUMISTA_KEY` = extracted from "NUMISTA_KEY=xxx" if present

---

## Phase 0: Session Setup

### Step 1: Create Browserbase session

```
browserbase_session_create
```

Record:
- `SESSION_ID` from the response
- Dashboard URL for session recording

### Step 2: Navigate to dev deployment

```
browserbase_stagehand_navigate → https://staktrakr.pages.dev/index.html
```

Record `BASE_URL = https://staktrakr.pages.dev`

### Step 3: Dismiss About modal

```
browserbase_stagehand_act: "Click the 'I Understand' button if a modal is visible"
```

If no modal appears, continue — this is not an error.

### Step 4: Baseline screenshot

```
browserbase_screenshot → name: "00-baseline"
```

### Step 5: Inject Numista API key (if provided)

Only if `NUMISTA_KEY` is set:

```
act: "Click the Settings gear icon in the header"
act: "Click the Numista section or tab in the settings panel"
act: "Clear and type the API key into the Numista API Key input field"
  → use variables parameter to pass key securely if supported, otherwise type directly
act: "Click Save or close the settings modal"
```

### Step 6: Record run metadata

Note:
- Today's date (YYYY-MM-DD) and start time
- `BASE_URL`
- `SESSION_ID` and dashboard URL
- Arguments used

---

## Phase 1: Core 13 Checks

Run each check in order (or only those in `CHECK_LIST`). For each check:

1. Use `stagehand_act` for all interactions (clicks, typing, navigation)
2. Use `stagehand_extract` for all assertions and data retrieval
3. Use `browserbase_screenshot` on failures and key states
4. Record ✅ pass · ⚠️ warn · ❌ fail with specific observed values

### Error Handling (applies to all checks)

- **Retry once** on unexpected results — wait 2 seconds, then retry the extract
- **Screenshot on failure** — `XX-FAIL-checkname` (e.g., `05-FAIL-filter-chips`)
- **Non-blocking** — failures do NOT abort the run; continue to next check
- **Session recovery** — on Stagehand error, navigate back to `BASE_URL/index.html`, dismiss modal if needed, retry the check once
- **SKIP** for API-dependent checks without keys — not counted as failure

---

### Check 1 — Page Load

**Extract:**
```
stagehand_extract: "Extract the page title, the number of spot price cards visible, and whether the tagline 'Your Stack. Your Way.' is visible on the page"
→ expect: { title: "StakTrakr", spotCardCount: 4, taglineVisible: true }
```

```
browserbase_screenshot → "01-page-load"
```

**Pass criteria:** title = "StakTrakr", spotCardCount ≥ 4, taglineVisible = true.

---

### Check 2 — Spot Prices

**Extract:**
```
stagehand_extract: "Extract the dollar values shown for Silver Spot Price, Gold Spot Price, Platinum Spot Price, and Palladium Spot Price from the spot price cards at the top of the page"
→ expect: all 4 values are non-null dollar amounts containing "$"
```

**Pass criteria:** All 4 metals return a non-null dollar value containing "$".

---

### Check 3 — Summary Cards

**Extract:**
```
stagehand_extract: "Count the number of summary cards visible (Silver, Gold, Platinum, Palladium, All Metals) and check if 'All Metals' is present"
→ expect: { cardCount: ≥5, allMetalsVisible: true }
```

**Pass criteria:** cardCount ≥ 5, allMetalsVisible = true.

---

### Check 4 — Inventory Count

**Extract:**
```
stagehand_extract: "Count the number of inventory item cards displayed and extract the item count label text (e.g., '8 items')"
→ expect: { itemCount: 8, countLabel: "8 items" }
```

**Pass criteria:** itemCount = 8, countLabel contains "8".

---

### Check 5 — Filter Chips

**Steps:**

1. Click Gold chip:
```
stagehand_act: "Click the Gold filter chip"
```

2. Extract filtered count:
```
stagehand_extract: "Count the number of inventory item cards currently displayed"
→ expect: 3
```

3. Clear filters:
```
stagehand_act: "Click the 'Clear All' button to reset filters"
```

4. Extract restored count:
```
stagehand_extract: "Count the number of inventory item cards currently displayed"
→ expect: 8
```

**Pass criteria:** afterFilter = 3, afterClear = 8.

---

### Check 6 — Search

**Steps:**

1. Type in search:
```
stagehand_act: "Type 'silver' into the search input field"
```

2. Extract count:
```
stagehand_extract: "Count the number of inventory item cards currently displayed"
→ expect: 3
```

3. Clear search:
```
stagehand_act: "Clear the search input field"
```

4. Extract restored count:
```
stagehand_extract: "Count the number of inventory item cards currently displayed"
→ expect: 8
```

**Pass criteria:** afterSearch = 3, afterClear = 8.

---

### Check 7 — Add Item

**Steps:**

1. Open add form:
```
stagehand_act: "Click the 'Add Item' button"
```

2. Fill form:
```
stagehand_act: "Select 'Silver' in the metal dropdown"
stagehand_act: "Select 'Bar' in the type dropdown"
stagehand_act: "Type 'BB-TEST-ITEM' in the name input field"
stagehand_act: "Type '50' in the purchase price input field"
stagehand_act: "Type '1' in the weight input field"
```

3. Submit:
```
stagehand_act: "Click the 'Add to Inventory' or Save/Submit button to add the item"
```

4. Verify:
```
stagehand_extract: "Count the number of inventory item cards currently displayed"
→ expect: 9
```

**Pass criteria:** itemCount = 9.

---

### Check 8 — Edit Item

> **Note:** Card views (A/B/C) have no direct edit button — clicking a card opens the view modal.
> Switch to table view (D) for reliable edit access, then restore card view after.

**Steps:**

1. Switch to table view:
```
stagehand_act: "Click the Table or D view style button in the card sort bar to switch to table view"
```

2. Find and open edit modal:
```
stagehand_act: "Click the edit (pencil) icon button on the BB-TEST-ITEM row in the inventory table"
```

3. Change price:
```
stagehand_act: "Clear the purchase price input field and type '60'"
```

4. Save:
```
stagehand_act: "Click the Save Changes button to submit the edit form"
```

5. Verify:
```
stagehand_extract: "Check if the BB-TEST-ITEM row in the inventory table now shows $60.00 or 60 in the purchase price column"
→ expect: true
```

6. Restore card view:
```
stagehand_act: "Click the C view style button in the card sort bar to switch back to card view C"
```

**Pass criteria:** Updated price visible in table row.

---

### Check 9 — Activity Log

**Steps:**

1. Open log:
```
stagehand_act: "Click the Log button in the header or toolbar"
```

2. Check for entry:
```
stagehand_extract: "Check if 'BB-TEST-ITEM' appears in the activity log entries"
→ expect: true
```

3. Close:
```
stagehand_act: "Close the activity log modal"
```

**Pass criteria:** BB-TEST-ITEM found in log.

---

### Check 10 — Card Views

**Steps:**

1. Switch to View A:
```
stagehand_act: "Click the View A card style button"
```
```
stagehand_extract: "Count the number of inventory item cards displayed"
→ expect: ≥9
```

2. Switch to View B:
```
stagehand_act: "Click the View B card style button"
```
```
stagehand_extract: "Count the number of inventory item cards displayed"
→ expect: ≥9
```

3. Restore default:
```
stagehand_act: "Click the View C or Table card style button to restore the default view"
```

**Pass criteria:** viewA ≥ 9, viewB ≥ 9.

---

### Check 11 — Theme Toggle

**Steps:**

1. Switch to light:
```
stagehand_act: "Click the theme toggle and select light mode"
```
```
browserbase_screenshot → "11-theme-light"
```
```
stagehand_extract: "What is the current theme mode — light or dark?"
→ expect: "light"
```

2. Switch to dark:
```
stagehand_act: "Click the theme toggle and select dark mode"
```
```
stagehand_extract: "What is the current theme mode — light or dark?"
→ expect: "dark"
```

**Pass criteria:** light mode confirmed, dark mode confirmed.

---

### Check 12 — Detail Modal

**Steps:**

1. Open a detail modal (not BB-TEST-ITEM):
```
stagehand_act: "Click on the first inventory item card that is not named BB-TEST-ITEM to open its detail modal"
```

2. Verify modal:
```
stagehand_extract: "Is a detail modal visible showing fields like Purchase Price, Melt Value, or Retail Price?"
→ expect: true
```
```
browserbase_screenshot → "12-detail-modal"
```

3. Close:
```
stagehand_act: "Close the detail modal"
```

**Pass criteria:** Modal visible with price fields.

---

### Check 13 — Delete + Cleanup

**Steps:**

1. Delete BB-TEST-ITEM:
```
stagehand_act: "Click the delete button on the BB-TEST-ITEM inventory card"
```

2. Confirm:
```
stagehand_act: "Click the Confirm or Delete button in the confirmation dialog"
```

3. Verify:
```
stagehand_extract: "Count the number of inventory item cards currently displayed"
→ expect: 8
```

**Pass criteria:** itemCount = 8 (back to original seed count).

---

## Phase 2: Extended Checks (14-18)

Skip this phase entirely if `QUICK` mode. Skip individual checks not in `CHECK_LIST`.

---

### Check 14 — API Verification (Numista)

**SKIP** if `NUMISTA_KEY` was not provided. Mark as `⏭️ SKIP — no API key`.

**Steps:**

1. Open a detail modal for a coin item:
```
stagehand_act: "Click on an inventory item that is a coin (not a bar) to open its detail modal"
```

2. Trigger Numista lookup:
```
stagehand_act: "Click the Numista Lookup button in the detail modal"
```

3. Extract catalog data:
```
stagehand_extract: "Extract any catalog data, Numista ID, or coin details returned from the Numista lookup"
```
```
browserbase_screenshot → "14-numista-lookup"
```

4. Close:
```
stagehand_act: "Close the modal"
```

**Pass criteria:** Catalog data returned (any non-empty Numista result).

---

### Check 15 — Settings Persistence

**Steps:**

1. Open settings:
```
stagehand_act: "Click the Settings gear icon"
```

2. Change items per page:
```
stagehand_act: "Change the items per page setting to 25"
```

3. Close settings:
```
stagehand_act: "Close the settings modal"
```

4. Reload page:
```
stagehand_navigate → https://staktrakr.pages.dev/index.html
stagehand_act: "Click the 'I Understand' button if a modal is visible"
```

5. Verify persistence:
```
stagehand_act: "Click the Settings gear icon"
```
```
stagehand_extract: "What is the current items per page setting value?"
→ expect: 25
```

6. Restore original:
```
stagehand_act: "Change the items per page setting back to the default value"
stagehand_act: "Close the settings modal"
```

**Pass criteria:** Items per page persisted as 25 after reload.

---

### Check 16 — Export Functions

**Steps:**

1. CSV export:
```
stagehand_act: "Click the CSV export button"
```
```
stagehand_extract: "Is there any error message visible on the page after clicking CSV export?"
→ expect: no error
```

2. PDF export:
```
stagehand_act: "Click the PDF export button"
```
```
stagehand_extract: "Is there any error message visible on the page after clicking PDF export?"
→ expect: no error
```
```
browserbase_screenshot → "16-export"
```

**Pass criteria:** No error messages after either export. (File downloads may be limited in cloud browser — absence of error is sufficient.)

---

### Check 17 — Vault Encrypt/Decrypt

> **Note:** Vault is NOT a standalone header button. It is inside Settings:
> Settings gear → Inventory tab → Export section → "Encrypted Backup" subsection.

**Steps:**

1. Open Settings and navigate to Vault:
```
stagehand_act: "Click the Settings gear icon in the header"
stagehand_act: "Click the Inventory tab or section in the settings panel"
stagehand_act: "Click the 'Encrypted Backup' or 'Vault' section within the Export section"
```

2. Create backup:
```
stagehand_act: "Click the Export or Create Backup button in the Encrypted Backup section"
stagehand_act: "Type 'TestPassword123!' into the password field"
stagehand_act: "Click the Export or confirm button to create the encrypted backup"
```

3. Verify UI flow:
```
stagehand_extract: "Is there a success message, 'Backup exported successfully', or download prompt visible?"
```
```
browserbase_screenshot → "17-vault"
```

4. Close:
```
stagehand_act: "Close the settings modal"
```

**Pass criteria:** Success message "Backup exported successfully" or download prompt appears. (File download verification is limited in cloud.)

---

### Check 18 — Multi-Currency

**Steps:**

1. Switch to EUR:
```
stagehand_act: "Click the Settings gear icon"
stagehand_act: "Change the display currency to EUR or Euro"
stagehand_act: "Close the settings modal"
```

2. Verify euro symbols:
```
stagehand_extract: "Are euro symbols (€) visible in the spot prices or inventory values on the page?"
→ expect: true
```
```
browserbase_screenshot → "18-multi-currency"
```

3. Restore USD:
```
stagehand_act: "Click the Settings gear icon"
stagehand_act: "Change the display currency back to USD"
stagehand_act: "Close the settings modal"
```

**Pass criteria:** Euro symbols visible after currency switch.

---

## Phase 3: Results Summary

```
Results
=======
| #  | Check                | Status       | Notes |
|----|----------------------|--------------|-------|
| 1  | Page Load            | ✅/⚠️/❌/⏭️ | ... |
| 2  | Spot Prices          | ✅/⚠️/❌/⏭️ | ... |
| 3  | Summary Cards        | ✅/⚠️/❌/⏭️ | ... |
| 4  | Inventory Count      | ✅/⚠️/❌/⏭️ | ... |
| 5  | Filter Chips         | ✅/⚠️/❌/⏭️ | ... |
| 6  | Search               | ✅/⚠️/❌/⏭️ | ... |
| 7  | Add Item             | ✅/⚠️/❌/⏭️ | ... |
| 8  | Edit Item            | ✅/⚠️/❌/⏭️ | ... |
| 9  | Activity Log         | ✅/⚠️/❌/⏭️ | ... |
| 10 | Card Views           | ✅/⚠️/❌/⏭️ | ... |
| 11 | Theme Toggle         | ✅/⚠️/❌/⏭️ | ... |
| 12 | Detail Modal         | ✅/⚠️/❌/⏭️ | ... |
| 13 | Delete + Cleanup     | ✅/⚠️/❌/⏭️ | ... |
| 14 | API Verification     | ✅/⚠️/❌/⏭️ | ... |
| 15 | Settings Persistence | ✅/⚠️/❌/⏭️ | ... |
| 16 | Export Functions      | ✅/⚠️/❌/⏭️ | ... |
| 17 | Vault Encrypt/Decrypt| ✅/⚠️/❌/⏭️ | ... |
| 18 | Multi-Currency       | ✅/⚠️/❌/⏭️ | ... |

Overall: ✅ PASS / ✅ PASS WITH WARNINGS / ❌ FAIL
```

Overall result rules:
- All ✅ (and ⏭️) → `✅ PASS`
- Any ⚠️, no ❌ → `✅ PASS WITH WARNINGS`
- Any ❌ → `❌ FAIL`

---

## Phase 4: Known Bugs Registry

Before filing any issues, check each warning or failure against the known active bugs.

**Do NOT file a new Linear issue for a known active bug.** Reference it in the run record only.

### Currently Known Active Bugs

| Bug ID | Description | Notes |
|---|---|---|
| BUG-001 | Search returns 0 results intermittently | Intermittent — not always triggered |
| BUG-002 | Autocomplete ghost text persists after modal close | Not always triggered |

### Resolved Bugs (do not re-file)

| Bug ID | Description | Resolved In |
|---|---|---|
| BUG-006 | Delete executed immediately with no confirmation dialog | v3.31.5 — replaced with `showBulkConfirm` DOM modal |
| STAK-205 | Edit Item — item disappears after edit flow | Automation artifact — Check 8 instructions fixed; cards have no direct edit button, use table view (D) instead |
| STAK-206 | Card view items-per-page constraint never applied | Fixed in dev — `pagination.js` row vs item unit mismatch corrected |

If a warning/fail matches a known bug → mark "known — skipping Linear issue".
If a warning/fail is **new** → file a Linear issue in Phase 5.

---

## Phase 5: File Linear Issues (new findings only)

**Skip entirely if `DRY_RUN` mode.** Instead, print what WOULD be filed.

For each **new** warning or failure:

Call `mcp__claude_ai_Linear__create_issue`:
- **team:** `f876864d-ff80-4231-ae6c-a8e5cb69aca4`
- **title:** `BUG: [Check Name] — [brief description]`
- **priority:** `2` (High) for ❌ fail · `3` (Normal) for ⚠️ warn
- **labels:** `["Bug", "268350a3-f7e5-467c-b793-4924a40b922a"]` (Bug + Sonnet)
- **description:**

```markdown
## Bug Report — BB Test Run [DATE]

**Check:** #[N] [Check Name]
**Status:** ❌ Fail / ⚠️ Warn
**Environment:** https://staktrakr.pages.dev; seed inventory
**Session Recording:** [Browserbase dashboard URL]

## Observed Behavior

[What was seen — include extract return values]

## Expected Behavior

[What should have happened]

## Reproduction Steps

1. Navigate to https://staktrakr.pages.dev/index.html
2. Run `/bb-test` skill
3. [Steps from the check definition above]

---
_Surfaced during BB test run on [DATE] via /bb-test skill (Browserbase Stagehand automation)._
```

---

## Phase 6: Create Run Record Issue

**Skip if `DRY_RUN` mode.**

Call `mcp__claude_ai_Linear__create_issue`:

- **team:** `f876864d-ff80-4231-ae6c-a8e5cb69aca4`
- **title:** `QA: BB Test Suite — [DATE formatted as "Feb 19, 2026"] [EMOJI] [RESULT]`
- **priority:** `4` (Low)
- **labels:** `["645a4bb1-0c34-477f-a8a6-14b75762178e", "268350a3-f7e5-467c-b793-4924a40b922a"]` (Improvement + Sonnet)
- **description:**

```markdown
## BB Test Suite — [DATE]

**Overall Result:** [OVERALL_RESULT]
**Run Method:** /bb-test skill via Claude Code (Browserbase Stagehand automation)
**Environment:** https://staktrakr.pages.dev; seed inventory ([N] items)
**Session Recording:** [Browserbase dashboard URL]
**Arguments:** [ARGUMENTS or "full suite"]

---

## Results

| # | Check | Status | Notes |
|---|-------|--------|-------|
[results table rows]

---

## New Issues Filed

[List new Linear issues, or "None — all findings matched known active bugs"]

## Known Issues Observed (not re-filed)

[List known bugs triggered this run]

## Known Issues Not Triggered

[List known bugs that did NOT appear this run]

---

_Logged by Claude via /bb-test skill. Covers 18 checks: Page Load, Spot Prices, Summary Cards, Inventory Count, Filter Chips, Search, Add Item, Edit Item, Activity Log, Card Views, Theme Toggle, Detail Modal, Delete + Cleanup, API Verification, Settings Persistence, Export Functions, Vault Encrypt/Decrypt, Multi-Currency._
```

After creating the run record issue, call `mcp__claude_ai_Linear__update_issue` to set status to **Done**.

---

## Phase 7: Cleanup & Confirm

Close the Browserbase session:
```
browserbase_session_close → SESSION_ID
```

Print summary:

```
BB Test complete!
=================
Environment: https://staktrakr.pages.dev
Session Recording: [dashboard URL]

Run Record: STAK-XXX → Done
  [url]

New bugs filed:
  STAK-XXX — [title]  (or "None")

Known bugs observed (not re-filed):
  BUG-001 — search intermittent  (or "None")
```

---

## Dry Run Mode

If `DRY_RUN`:
- Run all checks normally via Browserbase
- Print the results table
- Show what Linear issues WOULD be created (title, priority, description preview)
- Do NOT call any Linear MCP tools
- End with: `Dry run complete — no Linear issues created.`

---

## Quick Mode

If `QUICK`:
- Run only checks 1-13 (core checks)
- Skip checks 14-18 entirely (mark as ⏭️ SKIP)
- All other phases (results, Linear reporting) proceed normally

---

## Maintaining the Known Bugs Registry

When a bug is resolved and shipped, move it from Known Active Bugs to the Resolved table above. This ensures future runs correctly flag regressions rather than silently skipping them.
