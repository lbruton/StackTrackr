---
name: prime
description: >
  Session primer — comprehensive project status sweep. Run this at the start of every session
  to get oriented fast. Pulls GitHub issues, Linear issues, Linear projects, spec-workflow status,
  recent git activity, and mem0 context, then synthesizes a scannable status report with priorities.
  Use this skill whenever the user says "prime", "get me up to speed", "session status",
  "where are we", "what's the status", "catch me up", "project overview", "what's open",
  or any variant asking for a holistic view of project health and progress.
  Also use proactively at session start if the user hasn't run it yet and jumps straight into work —
  a quick prime helps avoid duplicate effort on already-closed issues.
---

# Prime — Session Status Sweep

Gather project state from all sources and synthesize a concise, scannable status report.
The goal is to orient the user in under 60 seconds so they can decide what to work on next.

## Execution Strategy

Speed matters — run all independent data fetches in parallel. The data sources below
have zero dependencies on each other, so launch them all in one turn.

### Parallel Data Fetches (all in one turn)

1. **mem0 recall** — search for recent context: roadmap, priorities, progress, blockers, infrastructure
   ```
   mcp__mem0__search_memories(query="roadmap priorities sprint progress blockers", filters={"AND": [{"agent_id": "<project-tag>"}]}, limit=10)
   ```

2. **GitHub open issues** — all open issues with labels and milestones
   ```bash
   gh issue list --repo lbruton/<repo> --state open --limit 50 \
     --json number,title,labels,milestone,state,createdAt
   ```

3. **GitHub recently closed** — closed in the last 7 days
   ```bash
   gh issue list --repo lbruton/<repo> --state closed --limit 40 \
     --json number,title,closedAt
   ```
   Filter to last 7 days in a python one-liner.

4. **Linear: Backlog issues**
   ```
   mcp__claude_ai_Linear__list_issues(team="<linearTeamId>", state="backlog", limit=50)
   ```

5. **Linear: Todo issues**
   ```
   mcp__claude_ai_Linear__list_issues(team="<linearTeamId>", state="todo", limit=50)
   ```

6. **Linear: In Progress issues**
   ```
   mcp__claude_ai_Linear__list_issues(team="<linearTeamId>", state="in progress", limit=50)
   ```

7. **Linear: Recently Done** (last 7 days)
   ```
   mcp__claude_ai_Linear__list_issues(team="<linearTeamId>", state="done", updatedAt="-P7D", limit=50)
   ```

8. **Linear: Projects/Sprints**
   ```
   mcp__claude_ai_Linear__list_projects(team="<linearTeamId>")
   ```

9. **Git activity** — commit count + recent tags
   ```bash
   git log --oneline --since="7 days ago" --no-merges | wc -l
   git tag --sort=-creatordate | head -10
   ```

10. **Spec-workflow: Active specs + approvals** — single bash command that scans both directories
    ```bash
    echo "=== ACTIVE SPECS ===" && \
    for spec_dir in .spec-workflow/specs/*/; do
      [ -d "$spec_dir" ] || continue
      spec_name=$(basename "$spec_dir")
      has_req=$( [ -f "$spec_dir/requirements.md" ] && echo "Y" || echo "-" )
      has_des=$( [ -f "$spec_dir/design.md" ] && echo "Y" || echo "-" )
      has_tsk=$( [ -f "$spec_dir/tasks.md" ] && echo "Y" || echo "-" )
      impl_count=$( ls "$spec_dir/Implementation Logs/" 2>/dev/null | grep -c '.md$' || echo 0 )
      task_total=$( grep -c '^\s*- \[' "$spec_dir/tasks.md" 2>/dev/null || echo 0 )
      task_done=$( grep -c '^\s*- \[x\]' "$spec_dir/tasks.md" 2>/dev/null || echo 0 )
      task_wip=$( grep -c '^\s*- \[-\]' "$spec_dir/tasks.md" 2>/dev/null || echo 0 )
      echo "$spec_name | req=$has_req des=$has_des tsk=$has_tsk | tasks=$task_done/$task_total wip=$task_wip | logs=$impl_count"
    done && \
    echo "=== PENDING APPROVALS ===" && \
    find .spec-workflow/approvals/ -name "approval_*.json" -exec python3 -c "
    import json,sys
    for f in sys.argv[1:]:
        d=json.loads(open(f).read())
        if d.get('status') == 'pending':
            print(f'PENDING: {d.get(\"title\",\"?\")}')
        elif d.get('status') == 'needs-revision':
            print(f'NEEDS REVISION: {d.get(\"title\",\"?\")}')
    " {} +
    ```

### Where to find project identifiers

Read `.claude/project.json` for:
- `tag` → use as mem0 `agent_id`
- `linearTeamId` → use for all Linear queries

The GitHub repo name matches the directory name (e.g., `StakTrakr`).

## Report Template

After all data returns, synthesize into this structure. Keep it tight — tables over prose.

```markdown
## This Week by the Numbers

| Metric | Count |
|--------|-------|
| Linear issues completed | **N** |
| GitHub issues closed | **N** |
| Commits (non-merge, 7d) | **N** |
| Patch versions shipped | vX.Y.Z1 → **vX.Y.Z2** (N patches) |

---

## Spec-Workflow Status

### Active Specs

| Spec | Phase | Tasks | Status |
|------|-------|-------|--------|
| STAK-NNN-slug | Phase 4 (Impl) | 3/5 done, 1 WIP | In progress |
| STAK-NNN-slug | Phase 2 (Design) | — | Awaiting approval |

Phase is determined by which files exist:
- Only requirements.md → Phase 1 (Requirements)
- + design.md → Phase 2 (Design)
- + tasks.md → Phase 3 (Tasks)
- + Implementation Logs/ with files → Phase 4 (Implementation)

If all tasks are [x] and impl log count matches task count → "Complete (ready to archive)"

### Pending Approvals

List any approvals with status "pending" or "needs-revision". These are blocking
spec progress and need user attention on the dashboard (localhost:5000).

If none pending, show: "No pending approvals."

---

## Major Arcs Completed

Brief list of significant themes/epics closed this week. Group related issues
into 3-5 bullet points rather than listing every issue individually.

---

## Open Bugs (by priority)

| Priority | Issue | Summary |
|----------|-------|---------|
| High | STAK-NNN | one-line description |
| Medium | STAK-NNN | one-line description |

---

## Open Features / Todo

| Priority | Issue | Summary |
|----------|-------|---------|
| High | STAK-NNN | one-line description |

---

## Backlog (longer-term)

| Issue | Summary |
|-------|---------|
| STAK-NNN | one-line description |

---

## Roadmap Projects

| Status | Project | Priority |
|--------|---------|----------|
| Done | SPRINT-Name | High |
| Active | SPRINT-Name | High |
| Not started | SPRINT-Name | Medium |

Mark a project "Done" if all its issues are completed.
Mark "Active" if it has in-progress or recently-done issues.
Otherwise "Not started" or "Backlog".

---

## Suggested Next Priorities

3-5 actionable recommendations based on:
- Unfinished bugs (highest priority first)
- Specs awaiting approval (user action needed)
- Specs in-flight that are close to completion
- Projects that are close to completion
- Blockers or stale items
- Quick wins vs. larger efforts
- Any relevant mem0 context (handoffs, decisions, planned next steps)
```

## Cross-referencing

- Note GitHub↔Linear duplicates (e.g., "GH #706 = STAK-408") so the user can consolidate
- Flag any issues that have been open > 30 days without activity
- If a Linear project has all issues done, recommend marking it "Completed"
- If active specs reference completed Linear issues, flag them as candidates for archiving

## Tone

Direct and scannable. Lead with numbers, use tables, skip filler.
The user should be able to glance at this and know exactly where things stand.
